reload <- function()
{ 
  unloadNamespace("cvm")
  require(cvm)
}
