<font size = 2>

### To-Do list for BCPA v 2.0

1. Change to `GetTau()`!

1. Create a `SummarizeChangePoints()` function that appropriately pools and filters the changepoints according to time unit width window and thresholds and returns a summary of change points and "directions" of changes.

2. Allow for a uniform (non-gappy) bcpa - should be me much faster without the continuous GetRho!

3. Make `PlotBCPA()` prettier ... with real time units?  More control of features? 

4. Figure out how to only print the "ws" part of a windowsweep.  (Write a print method?)
